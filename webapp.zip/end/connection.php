<?php
// syntax
// mysqli_connect("server" , "username" , "password" , "database");
$conn = mysqli_connect("localhost" , "root" , "" , "hfyql1ju_SEGP") or die("Connection Failed");
?>